# rocketdoo/__init__.py (el del paquete)
"""
🚀 Rocketdoo - Framework para entornos Odoo
"""

__version__ = "2.0.1b4"
